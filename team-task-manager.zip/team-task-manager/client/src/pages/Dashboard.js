import React, { useEffect, useState } from 'react';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

const statusBadge = (status, due) => {
  if (due && new Date(due) < new Date() && status !== 'done') return <span className="badge badge-overdue">Overdue</span>;
  const map = { todo: 'badge-todo', 'in-progress': 'badge-in-progress', done: 'badge-done' };
  return <span className={`badge ${map[status]}`}>{status}</span>;
};

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    api.get('/dashboard').then(r => { setData(r.data); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  if (loading) return <div className="loading">Loading dashboard...</div>;

  const stats = data?.stats || {};

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Dashboard</h1>
          <p style={{ color: '#6b7280', fontSize: 14, marginTop: 4 }}>Welcome back, {user?.name}! 👋</p>
        </div>
      </div>

      <div className="stats-grid">
        {[
          { label: 'Total Tasks', value: stats.total_tasks || 0, icon: '📋', color: '#ede9fe', text: '#5b21b6' },
          { label: 'Todo', value: stats.todo || 0, icon: '⏳', color: '#f3f4f6', text: '#374151' },
          { label: 'In Progress', value: stats.in_progress || 0, icon: '🔄', color: '#dbeafe', text: '#1d4ed8' },
          { label: 'Completed', value: stats.done || 0, icon: '✅', color: '#d1fae5', text: '#065f46' },
          { label: 'Overdue', value: stats.overdue || 0, icon: '🚨', color: '#fee2e2', text: '#991b1b' },
        ].map(s => (
          <div key={s.label} className="stat-card">
            <div className="stat-icon" style={{ background: s.color }}>
              <span style={{ fontSize: 22 }}>{s.icon}</span>
            </div>
            <div className="stat-info">
              <h3 style={{ color: s.text }}>{s.value}</h3>
              <p>{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        <div className="card">
          <h3 style={{ fontWeight: 600, marginBottom: 16, fontSize: 16 }}>Recent Tasks</h3>
          {data?.recentTasks?.length === 0
            ? <div className="empty-state"><p>No tasks yet</p></div>
            : <div className="table-wrap">
                <table>
                  <thead><tr><th>Task</th><th>Status</th><th>Project</th></tr></thead>
                  <tbody>
                    {data?.recentTasks?.map(t => (
                      <tr key={t.id}>
                        <td style={{ fontWeight: 500 }}>{t.title}</td>
                        <td>{statusBadge(t.status, t.due_date)}</td>
                        <td style={{ color: '#6b7280', fontSize: 13 }}>{t.project_name}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
          }
        </div>

        <div className="card">
          <h3 style={{ fontWeight: 600, marginBottom: 16, fontSize: 16 }}>Projects Progress</h3>
          {data?.projectStats?.length === 0
            ? <div className="empty-state"><p>No projects yet</p></div>
            : data?.projectStats?.map(p => {
                const pct = p.total > 0 ? Math.round((p.completed / p.total) * 100) : 0;
                return (
                  <div key={p.id} style={{ marginBottom: 16, cursor: 'pointer' }} onClick={() => navigate(`/projects/${p.id}`)}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                      <span style={{ fontSize: 14, fontWeight: 500 }}>{p.name}</span>
                      <span style={{ fontSize: 13, color: '#6b7280' }}>{p.completed}/{p.total}</span>
                    </div>
                    <div style={{ background: '#e5e7eb', borderRadius: 99, height: 8 }}>
                      <div style={{ background: '#4f46e5', borderRadius: 99, height: 8, width: `${pct}%`, transition: 'width 0.5s' }} />
                    </div>
                  </div>
                );
              })
          }
        </div>
      </div>
    </div>
  );
}
