import React, { useEffect, useState } from 'react';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';

export default function Tasks() {
  const [tasks, setTasks] = useState([]);
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  const fetchTasks = () => {
    api.get('/tasks').then(r => { setTasks(r.data); setLoading(false); });
  };

  useEffect(() => { fetchTasks(); }, []);

  const updateStatus = async (id, status) => {
    await api.put(`/tasks/${id}`, { status });
    fetchTasks();
  };

  const filtered = tasks.filter(t => {
    if (filter === 'overdue') return t.due_date && new Date(t.due_date) < new Date() && t.status !== 'done';
    if (filter === 'mine') return t.assigned_to === user?.id;
    if (filter === 'all') return true;
    return t.status === filter;
  });

  if (loading) return <div className="loading">Loading tasks...</div>;

  return (
    <div>
      <div className="page-header">
        <h1>All Tasks</h1>
        <span style={{ color: '#6b7280', fontSize: 14 }}>{filtered.length} tasks</span>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 20, flexWrap: 'wrap' }}>
        {[
          { key: 'all', label: 'All' },
          { key: 'mine', label: 'Mine' },
          { key: 'todo', label: 'Todo' },
          { key: 'in-progress', label: 'In Progress' },
          { key: 'done', label: 'Done' },
          { key: 'overdue', label: '🚨 Overdue' },
        ].map(f => (
          <button key={f.key} className={`btn ${filter === f.key ? 'btn-primary' : 'btn-outline'} btn-sm`}
            onClick={() => setFilter(f.key)}>{f.label}</button>
        ))}
      </div>

      <div className="card">
        {filtered.length === 0
          ? <div className="empty-state"><p>No tasks found.</p></div>
          : <div className="table-wrap">
              <table>
                <thead><tr><th>Task</th><th>Project</th><th>Status</th><th>Priority</th><th>Assigned To</th><th>Due Date</th></tr></thead>
                <tbody>
                  {filtered.map(t => {
                    const isOverdue = t.due_date && new Date(t.due_date) < new Date() && t.status !== 'done';
                    const canEdit = user?.role === 'admin' || t.assigned_to === user?.id;
                    return (
                      <tr key={t.id} className={isOverdue ? 'overdue-row' : ''}>
                        <td>
                          <div style={{ fontWeight: 500 }}>{t.title}</div>
                          {t.description && <div style={{ fontSize: 12, color: '#9ca3af' }}>{t.description}</div>}
                        </td>
                        <td style={{ fontSize: 13, color: '#6b7280' }}>{t.project_name}</td>
                        <td>
                          {canEdit
                            ? <select className="form-control" style={{ width: 'auto', padding: '4px 8px', fontSize: 13 }}
                                value={t.status} onChange={e => updateStatus(t.id, e.target.value)}>
                                <option value="todo">Todo</option>
                                <option value="in-progress">In Progress</option>
                                <option value="done">Done</option>
                              </select>
                            : <span className={`badge badge-${isOverdue ? 'overdue' : t.status}`}>
                                {isOverdue ? 'Overdue' : t.status}
                              </span>
                          }
                        </td>
                        <td><span className={`badge badge-${t.priority}`}>{t.priority}</span></td>
                        <td style={{ fontSize: 13, color: '#6b7280' }}>{t.assigned_name || '—'}</td>
                        <td style={{ fontSize: 13, color: isOverdue ? '#ef4444' : '#6b7280' }}>
                          {t.due_date ? new Date(t.due_date).toLocaleDateString() : '—'}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
        }
      </div>
    </div>
  );
}
