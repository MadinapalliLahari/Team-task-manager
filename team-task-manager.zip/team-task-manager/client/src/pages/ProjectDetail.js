import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';

const priorityBadge = p => <span className={`badge badge-${p}`}>{p}</span>;
const statusBadge = (s, due) => {
  if (due && new Date(due) < new Date() && s !== 'done') return <span className="badge badge-overdue">Overdue</span>;
  const map = { todo: 'badge-todo', 'in-progress': 'badge-in-progress', done: 'badge-done' };
  return <span className={`badge ${map[s]}`}>{s}</span>;
};

export default function ProjectDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isAdmin, user } = useAuth();
  const [project, setProject] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [members, setMembers] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [tab, setTab] = useState('tasks');
  const [showTaskModal, setShowTaskModal] = useState(false);
  const [editTask, setEditTask] = useState(null);
  const [taskForm, setTaskForm] = useState({ title: '', description: '', assigned_to: '', due_date: '', priority: 'medium' });
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const fetch = async () => {
    const [proj, t, m] = await Promise.all([
      api.get(`/projects/${id}`), api.get(`/tasks?project_id=${id}`), api.get(`/projects/${id}/members`)
    ]);
    setProject(proj.data); setTasks(t.data); setMembers(m.data);
    if (isAdmin) { const u = await api.get('/users'); setAllUsers(u.data); }
  };

  useEffect(() => { fetch(); }, [id]);

  const openCreate = () => {
    setEditTask(null);
    setTaskForm({ title: '', description: '', assigned_to: '', due_date: '', priority: 'medium' });
    setShowTaskModal(true);
  };

  const openEdit = (t) => {
    setEditTask(t);
    setTaskForm({ title: t.title, description: t.description || '', assigned_to: t.assigned_to || '', due_date: t.due_date ? t.due_date.split('T')[0] : '', priority: t.priority });
    setShowTaskModal(true);
  };

  const saveTask = async (e) => {
    e.preventDefault();
    setError('');
    setSaving(true);
    try {
      if (editTask) await api.put(`/tasks/${editTask.id}`, { ...taskForm, project_id: id });
      else await api.post('/tasks', { ...taskForm, project_id: id });
      setShowTaskModal(false);
      fetch();
    } catch (err) { setError(err.response?.data?.error || 'Error saving task.'); }
    finally { setSaving(false); }
  };

  const updateStatus = async (taskId, status) => {
    await api.put(`/tasks/${taskId}`, { status });
    fetch();
  };

  const deleteTask = async (taskId) => {
    if (!window.confirm('Delete this task?')) return;
    await api.delete(`/tasks/${taskId}`);
    fetch();
  };

  const addMember = async (userId) => {
    await api.post(`/projects/${id}/members`, { user_id: userId });
    fetch();
  };

  const removeMember = async (userId) => {
    await api.delete(`/projects/${id}/members/${userId}`);
    fetch();
  };

  if (!project) return <div className="loading">Loading...</div>;

  const nonMembers = allUsers.filter(u => !members.find(m => m.id === u.id));

  return (
    <div>
      <div className="page-header">
        <div>
          <button className="btn btn-outline btn-sm" style={{ marginBottom: 8 }} onClick={() => navigate('/projects')}>← Back</button>
          <h1>📁 {project.name}</h1>
          {project.description && <p style={{ color: '#6b7280', fontSize: 14, marginTop: 4 }}>{project.description}</p>}
        </div>
        {isAdmin && tab === 'tasks' && <button className="btn btn-primary" onClick={openCreate}>+ Add Task</button>}
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
        {['tasks', 'members'].map(t => (
          <button key={t} className={`btn ${tab === t ? 'btn-primary' : 'btn-outline'}`} onClick={() => setTab(t)}>
            {t === 'tasks' ? `📋 Tasks (${tasks.length})` : `👥 Members (${members.length})`}
          </button>
        ))}
      </div>

      {tab === 'tasks' && (
        <div className="card">
          {tasks.length === 0
            ? <div className="empty-state"><p>No tasks. {isAdmin ? 'Add your first task!' : ''}</p></div>
            : <div className="table-wrap">
                <table>
                  <thead><tr><th>Task</th><th>Status</th><th>Priority</th><th>Assigned To</th><th>Due Date</th>{isAdmin && <th>Actions</th>}</tr></thead>
                  <tbody>
                    {tasks.map(t => (
                      <tr key={t.id} className={t.due_date && new Date(t.due_date) < new Date() && t.status !== 'done' ? 'overdue-row' : ''}>
                        <td><div style={{ fontWeight: 500 }}>{t.title}</div>{t.description && <div style={{ fontSize: 12, color: '#9ca3af', marginTop: 2 }}>{t.description}</div>}</td>
                        <td>
                          {isAdmin
                            ? <select className="form-control" style={{ width: 'auto', padding: '4px 8px', fontSize: 13 }}
                                value={t.status} onChange={e => updateStatus(t.id, e.target.value)}>
                                <option value="todo">Todo</option>
                                <option value="in-progress">In Progress</option>
                                <option value="done">Done</option>
                              </select>
                            : (t.assigned_to === user?.id
                              ? <select className="form-control" style={{ width: 'auto', padding: '4px 8px', fontSize: 13 }}
                                  value={t.status} onChange={e => updateStatus(t.id, e.target.value)}>
                                  <option value="todo">Todo</option>
                                  <option value="in-progress">In Progress</option>
                                  <option value="done">Done</option>
                                </select>
                              : statusBadge(t.status, t.due_date)
                            )
                          }
                        </td>
                        <td>{priorityBadge(t.priority)}</td>
                        <td style={{ fontSize: 13, color: '#6b7280' }}>{t.assigned_name || '—'}</td>
                        <td style={{ fontSize: 13, color: t.due_date && new Date(t.due_date) < new Date() && t.status !== 'done' ? '#ef4444' : '#6b7280' }}>
                          {t.due_date ? new Date(t.due_date).toLocaleDateString() : '—'}
                        </td>
                        {isAdmin && <td>
                          <div style={{ display: 'flex', gap: 6 }}>
                            <button className="btn btn-outline btn-sm" onClick={() => openEdit(t)}>✏️</button>
                            <button className="btn btn-danger btn-sm" onClick={() => deleteTask(t.id)}>🗑</button>
                          </div>
                        </td>}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
          }
        </div>
      )}

      {tab === 'members' && (
        <div style={{ display: 'grid', gap: 16 }}>
          <div className="card">
            <h3 style={{ fontWeight: 600, marginBottom: 16 }}>Current Members</h3>
            {members.map(m => (
              <div key={m.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid #f3f4f6' }}>
                <div>
                  <div style={{ fontWeight: 500 }}>{m.name}</div>
                  <div style={{ fontSize: 13, color: '#6b7280' }}>{m.email}</div>
                </div>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <span className={`badge badge-${m.role}`}>{m.role}</span>
                  {isAdmin && m.id !== user?.id && <button className="btn btn-danger btn-sm" onClick={() => removeMember(m.id)}>Remove</button>}
                </div>
              </div>
            ))}
          </div>

          {isAdmin && nonMembers.length > 0 && (
            <div className="card">
              <h3 style={{ fontWeight: 600, marginBottom: 16 }}>Add Member</h3>
              {nonMembers.map(u => (
                <div key={u.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid #f3f4f6' }}>
                  <div>
                    <div style={{ fontWeight: 500 }}>{u.name}</div>
                    <div style={{ fontSize: 13, color: '#6b7280' }}>{u.email}</div>
                  </div>
                  <button className="btn btn-primary btn-sm" onClick={() => addMember(u.id)}>+ Add</button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {showTaskModal && (
        <div className="modal-overlay" onClick={() => setShowTaskModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>{editTask ? 'Edit Task' : 'New Task'}</h3>
              <button className="modal-close" onClick={() => setShowTaskModal(false)}>×</button>
            </div>
            <form onSubmit={saveTask}>
              <div className="modal-body">
                {error && <div className="alert alert-error">{error}</div>}
                <div className="form-group">
                  <label>Title *</label>
                  <input className="form-control" placeholder="Task title" value={taskForm.title}
                    onChange={e => setTaskForm({ ...taskForm, title: e.target.value })} required />
                </div>
                <div className="form-group">
                  <label>Description</label>
                  <textarea className="form-control" rows={2} value={taskForm.description}
                    onChange={e => setTaskForm({ ...taskForm, description: e.target.value })} />
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div className="form-group">
                    <label>Assign To</label>
                    <select className="form-control" value={taskForm.assigned_to}
                      onChange={e => setTaskForm({ ...taskForm, assigned_to: e.target.value })}>
                      <option value="">Unassigned</option>
                      {members.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                    </select>
                  </div>
                  <div className="form-group">
                    <label>Priority</label>
                    <select className="form-control" value={taskForm.priority}
                      onChange={e => setTaskForm({ ...taskForm, priority: e.target.value })}>
                      <option value="low">Low</option>
                      <option value="medium">Medium</option>
                      <option value="high">High</option>
                    </select>
                  </div>
                </div>
                <div className="form-group">
                  <label>Due Date</label>
                  <input type="date" className="form-control" value={taskForm.due_date}
                    onChange={e => setTaskForm({ ...taskForm, due_date: e.target.value })} />
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-outline" onClick={() => setShowTaskModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving...' : 'Save Task'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
