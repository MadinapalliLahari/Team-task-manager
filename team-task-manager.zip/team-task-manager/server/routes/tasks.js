const router = require('express').Router();
const pool = require('../config/db');
const { verifyToken, isAdmin } = require('../middleware/auth');

// GET /api/tasks?project_id=X
router.get('/', verifyToken, async (req, res) => {
  try {
    const { project_id } = req.query;
    let query = `SELECT t.*, u.name as assigned_name, p.name as project_name
      FROM tasks t
      LEFT JOIN users u ON t.assigned_to = u.id
      LEFT JOIN projects p ON t.project_id = p.id`;
    const params = [];
    if (project_id) {
      query += ' WHERE t.project_id=$1';
      params.push(project_id);
    } else if (req.user.role !== 'admin') {
      query += ` WHERE t.project_id IN (
        SELECT project_id FROM project_members WHERE user_id=$1
      )`;
      params.push(req.user.id);
    }
    query += ' ORDER BY t.created_at DESC';
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error.' });
  }
});

// POST /api/tasks (admin only)
router.post('/', verifyToken, isAdmin, async (req, res) => {
  try {
    const { title, description, project_id, assigned_to, due_date, priority } = req.body;
    if (!title || !project_id)
      return res.status(400).json({ error: 'Title and project are required.' });
    const result = await pool.query(
      `INSERT INTO tasks (title, description, project_id, assigned_to, due_date, priority, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [title, description, project_id, assigned_to || null, due_date || null, priority || 'medium', req.user.id]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error.' });
  }
});

// GET /api/tasks/:id
router.get('/:id', verifyToken, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT t.*, u.name as assigned_name FROM tasks t
       LEFT JOIN users u ON t.assigned_to = u.id WHERE t.id=$1`,
      [req.params.id]
    );
    if (!result.rows.length) return res.status(404).json({ error: 'Task not found.' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error.' });
  }
});

// PUT /api/tasks/:id - update task status (members can update status, admins can update all)
router.put('/:id', verifyToken, async (req, res) => {
  try {
    const { title, description, status, priority, assigned_to, due_date } = req.body;
    const task = await pool.query('SELECT * FROM tasks WHERE id=$1', [req.params.id]);
    if (!task.rows.length) return res.status(404).json({ error: 'Task not found.' });

    let query, params;
    if (req.user.role === 'admin') {
      query = `UPDATE tasks SET title=$1, description=$2, status=$3, priority=$4, assigned_to=$5, due_date=$6
               WHERE id=$7 RETURNING *`;
      params = [title, description, status, priority, assigned_to || null, due_date || null, req.params.id];
    } else {
      // Members can only update status
      query = 'UPDATE tasks SET status=$1 WHERE id=$2 RETURNING *';
      params = [status, req.params.id];
    }
    const result = await pool.query(query, params);
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error.' });
  }
});

// DELETE /api/tasks/:id (admin only)
router.delete('/:id', verifyToken, isAdmin, async (req, res) => {
  try {
    await pool.query('DELETE FROM tasks WHERE id=$1', [req.params.id]);
    res.json({ message: 'Task deleted.' });
  } catch (err) {
    res.status(500).json({ error: 'Server error.' });
  }
});

module.exports = router;
