const router = require('express').Router();
const pool = require('../config/db');
const { verifyToken } = require('../middleware/auth');

// GET /api/dashboard
router.get('/', verifyToken, async (req, res) => {
  try {
    let projectFilter = '';
    let params = [];

    if (req.user.role !== 'admin') {
      projectFilter = `AND t.project_id IN (SELECT project_id FROM project_members WHERE user_id=$1)`;
      params = [req.user.id];
    }

    const stats = await pool.query(`
      SELECT
        COUNT(*) FILTER (WHERE true) as total_tasks,
        COUNT(*) FILTER (WHERE status = 'todo') as todo,
        COUNT(*) FILTER (WHERE status = 'in-progress') as in_progress,
        COUNT(*) FILTER (WHERE status = 'done') as done,
        COUNT(*) FILTER (WHERE due_date < NOW() AND status != 'done') as overdue
      FROM tasks t WHERE true ${projectFilter}
    `, params);

    const recentTasks = await pool.query(`
      SELECT t.id, t.title, t.status, t.priority, t.due_date,
             u.name as assigned_name, p.name as project_name
      FROM tasks t
      LEFT JOIN users u ON t.assigned_to = u.id
      LEFT JOIN projects p ON t.project_id = p.id
      WHERE true ${projectFilter}
      ORDER BY t.created_at DESC LIMIT 5
    `, params);

    const projectStats = await pool.query(`
      SELECT p.id, p.name,
        COUNT(t.id) as total,
        COUNT(t.id) FILTER (WHERE t.status='done') as completed
      FROM projects p
      LEFT JOIN tasks t ON t.project_id = p.id
      ${req.user.role !== 'admin' ? 'JOIN project_members pm ON pm.project_id = p.id AND pm.user_id=$1' : ''}
      GROUP BY p.id ORDER BY p.created_at DESC LIMIT 5
    `, req.user.role !== 'admin' ? [req.user.id] : []);

    res.json({
      stats: stats.rows[0],
      recentTasks: recentTasks.rows,
      projectStats: projectStats.rows
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error.' });
  }
});

module.exports = router;
