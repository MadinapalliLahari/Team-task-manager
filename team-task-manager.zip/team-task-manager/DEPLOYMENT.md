# 🚀 DEPLOYMENT GUIDE — Step by Step

Follow these steps exactly in order. Takes about 90 minutes total.

---

## STEP 1: Install Tools on Your Computer (15 min)

1. Install Node.js → https://nodejs.org (LTS version)
2. Install Git → https://git-scm.com/download/win
3. Open Command Prompt and verify:
   node --version   ← should show v18 or higher
   git --version    ← should show a version number

---

## STEP 2: Create Accounts (10 min)

1. Railway → https://railway.app → "Login with GitHub"
2. Vercel  → https://vercel.com  → "Continue with GitHub"

---

## STEP 3: Push Code to GitHub (10 min)

Open Command Prompt in the team-task-manager folder:

  cd path\to\team-task-manager

  git init
  git add .
  git commit -m "Initial commit: Team Task Manager"

Go to GitHub.com → New Repository → name it "team-task-manager" → Create
Then run (replace YOUR_USERNAME):

  git remote add origin https://github.com/YOUR_USERNAME/team-task-manager.git
  git branch -M main
  git push -u origin main

✅ Your code is now on GitHub!

---

## STEP 4: Deploy Backend on Railway (20 min)

1. Go to https://railway.app
2. Click "New Project" → "Deploy from GitHub repo"
3. Select "team-task-manager"
4. Railway will ask for root directory → type: server
5. Click "Add Service" → "Database" → "Add PostgreSQL"
6. Click on the PostgreSQL service → "Connect" tab → copy the DATABASE_URL

Now set environment variables (click on your server service → Variables):
   DATABASE_URL    = (paste the one you copied)
   JWT_SECRET      = mySecretKey123ChangeThis
   NODE_ENV        = production
   CLIENT_URL      = (leave blank for now, add after Vercel deploy)

7. Go to the server service → Settings → copy the Railway domain
   It will look like: https://team-task-manager-production.up.railway.app

8. Run the database schema:
   Click PostgreSQL service → "Query" tab → paste contents of server/config/schema.sql → Run

9. Also run these seed commands to create demo accounts:
   INSERT INTO users (name, email, password, role) VALUES
   ('Admin User', 'admin@demo.com', '$2b$10$YourHashHere', 'admin');

   Actually use the app Register page to create accounts after deployment instead!

✅ Backend is live! Test it: https://your-railway-url.railway.app/
   Should show: {"message":"Team Task Manager API running ✅"}

---

## STEP 5: Deploy Frontend on Vercel (15 min)

1. Go to https://vercel.com
2. Click "Add New" → "Project"
3. Import your GitHub repo "team-task-manager"
4. Set Root Directory → click Edit → type: client → Continue
5. Under Environment Variables, add:
   REACT_APP_API_URL = https://your-railway-url.railway.app/api
   (use the Railway URL from Step 4)
6. Click "Deploy"

Wait 2-3 minutes...

✅ Frontend is live! Copy your Vercel URL (e.g. https://team-task-manager.vercel.app)

---

## STEP 6: Connect Frontend & Backend (5 min)

1. Go to Railway → your server service → Variables
2. Add: CLIENT_URL = https://your-vercel-url.vercel.app
3. Railway will redeploy automatically

---

## STEP 7: Seed Demo Data (10 min)

1. Open your live Vercel URL
2. Click "Sign up" → create an Admin account:
   Name: Admin User
   Email: admin@demo.com
   Password: demo1234
   Role: Admin

3. Click "Sign up" again → create a Member account:
   Name: Member User
   Email: member@demo.com
   Password: demo1234
   Role: Member

4. Login as Admin → Create 2 projects → Add Member to both
5. Create 5-6 tasks with different statuses and due dates (set some as past dates to show overdue)

---

## STEP 8: Update README (5 min)

Edit README.md:
- Replace YOUR_USERNAME with your GitHub username
- Replace https://your-app.vercel.app with your actual Vercel URL
- Push: git add . && git commit -m "Update README with live URLs" && git push

---

## STEP 9: Record Demo Video with Loom (15 min)

1. Go to https://loom.com → Sign up free → "New Video"
2. Choose "Screen + Cam" → Start recording

Script (say this while recording):
00:00 - "Hi, I'm [name]. This is TaskFlow, a full-stack Team Task Manager."
00:15 - Show the login page → "It has JWT authentication with role-based access."
00:30 - Login as Admin → "This is the admin dashboard showing task stats."
01:00 - Create a new project → "Admins can create projects and invite members."
01:30 - Add tasks with different priorities and due dates → "Tasks can be assigned with priority levels."
02:00 - Log out → Login as Member → "Members see only their assigned projects."
02:30 - Update a task status → "Members can update their task status."
02:45 - Switch back to Admin → Show dashboard updating → "The dashboard reflects real-time changes."
03:00 - Show Team page → "Admins can manage the full team."

3. Stop recording → Copy the Loom link
4. Add to README.md

---

## SUBMISSION CHECKLIST ✅

[ ] Live URL: https://your-app.vercel.app (fully working)
[ ] GitHub Repo: https://github.com/YOUR_USERNAME/team-task-manager
[ ] README.md with live URL, setup instructions, API docs
[ ] Demo Video: 3-5 min Loom link

DONE! Submit these 4 things. Good luck! 🎉
